'use client';

import { useEffect, useRef } from 'react';

// Vídeo curto que repete sem som. O Safari só toca sozinho se o "mudo" estiver ligado de verdade no elemento,
// então ligamos por código e mandamos tocar; se mesmo assim ele bloquear (modo de economia), toca no primeiro toque na página.
export function VideoLoop({ src }: { src: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const v = ref.current; if (!v) return;
    v.muted = true; v.defaultMuted = true; v.setAttribute('muted', ''); v.setAttribute('playsinline', ''); v.setAttribute('webkit-playsinline', '');
    const tocar = () => { void v.play().catch(() => { /* bloqueado: tenta de novo no primeiro toque */ }); };
    tocar();
    const aoTocar = () => { tocar(); window.removeEventListener('touchstart', aoTocar); window.removeEventListener('click', aoTocar); };
    window.addEventListener('touchstart', aoTocar, { once: true, passive: true });
    window.addEventListener('click', aoTocar, { once: true });
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) tocar(); }, { threshold: 0.2 });
    obs.observe(v);
    return () => { obs.disconnect(); window.removeEventListener('touchstart', aoTocar); window.removeEventListener('click', aoTocar); };
  }, [src]);
  return <video ref={ref} src={src} autoPlay loop muted playsInline preload="auto" disablePictureInPicture aria-hidden="true" />;
}
